<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-image: url('../imagenes/fondogremio.jpg'); ">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <div class="container" style="padding-top: 20px;">
        <h1>Hola, bienvenido al bestiario online.</h1>
        <p style="margin: 20px;">Esta es nuestra página informativa sobre monster hunter y todo su contenido, espero que te sea de gran ayuda</p>
    
    </div>
    <div class="card container" style="width: 25rem; background-color: lightblue; padding-top: 5px;">
        <img class="card-img-top" src="../imagenes/correcto.png" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Buenas tardes</h5>
            <p class="card-text">Mas abajo pordras encontrar el boton para entrar a nuestra maravillosa web donde encontraras todo lo que debes saber para tener una buena caceria.</p>
    </div>
</div>
    
</body>
<footer class="card text-center fixed-bottom" style="background-color: lightblue;">
        <div>
            <div class="card-body">
                <h5>Pasalo bien</h5>
                <p class="card-text">Aqui encontrarás todo tipo de datos y avistamiento de criaturas</p>
                <a href="login.php" class="btn btn-primary">¡Vamos a entrar!</a>
            </div>
        </div>
</footer>

</html>